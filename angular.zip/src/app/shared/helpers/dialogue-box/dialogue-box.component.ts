import { Component, Inject, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
import { globalUrl } from '../globalUrl';


@Component({
  selector: 'app-dialogbox',
  templateUrl: './dialogue-box.component.html',
  styleUrls: ['./dialogue-box.component.css']
})
export class DialogboxComponent implements OnInit {
  open() {
    throw new Error('Method not implemented.');
  }


  constructor(
    public dialogRef: MatDialogRef<DialogboxComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
    // private apiService: ApiService,
    // private toastr: ToastrService
  ) {}
 

  ngOnInit(): void {
  }

  onYesClick(): void {
    this.dialogRef.close(true); // User clicked on 'Yes', pass true to indicate confirmation
  }

  onNoClick(): void {
    this.dialogRef.close(false); // User clicked on 'No', pass false to indicate cancellation
  }

}


