
  import { Injectable } from '@angular/core';
  import { HttpClient } from '@angular/common/http';
  import { globalUrl } from '../globalUrl';
  import { Observable } from 'rxjs';
 
  @Injectable({
      providedIn: 'root',
    })
    export class ApiService {
     
    deleteAllDetails: any;
    
    
      constructor(private http: HttpClient) {}
    
      getAllDetails(url:any)  {
        return this.http.get<any>(url);
      }
    
      public getDetailsPagination(url: string, pageNumber: number, pageSize: number) {
        return this.http.get<any[]>(`${url}?pageNumber=${pageNumber}&pageSize=${pageSize}`, {}); 
      }
      
    
      postAllDetails(url: string, payload: any): Observable<any> {
        return this.http.post<any>(url, payload);
      }

      deleteItem(url: string, id: number) {  
        console.log('${url}/${id}');
        return this.http.delete<any>(`${url}/${id}`);
      }
    
      
      getDetailsById(url: string, api_id: any) {
        return this.http.get<any[]>(url +'?cityId=' +api_id, { });
      }


      getExport(url: any): Observable<any> {
        console.log('Calling getExport:', url);
        return this.http.get(url);
      }
      downloadFile(url: string, fileName?:any) {
        if(fileName){
            return this.http.get(`${url}?fileName=${fileName}`,{ responseType: 'blob' })
          }
          else{
            return this.http.get(url,{ responseType: 'blob' })
          }
          }
      
    }
 

    
  