import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
import { globalUrl } from 'src/app/shared/helpers/globalUrl';
import { ToastrService } from 'ngx-toastr';
import saveAs from 'file-saver';
import * as XLSX from 'xlsx';
@Injectable({
    providedIn: 'root',
  })
  export class ApiFacade {
  deleteItem: any;
  static deleteItem: any;
  deletedData: any;
  editedData: any;
  exportDataAsExcel: any;
  http: any;
  saveFormInput: any;
    constructor(private apiService: ApiService, private toastr: ToastrService) {}
  
    async getAllCity() {
        return new Promise(resolve => {
              return this.apiService.getAllDetails(globalUrl.city).subscribe(res => {
                    resolve(res);
                    console.log(res);
                  });
                });
    }

     async getPaginatedCity() {
      return new Promise(resolve =>{
      return this.apiService.getAllDetails(globalUrl.paginate).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log("console running")
    });
    
    
    });
  }
  getState(){
    return new Promise(resolve =>{
      return this.apiService.getAllDetails(globalUrl.state).subscribe(res => {
        resolve(res);
        console.log(res);
    });
    });

  }

  getCountry(){
    return new Promise(resolve =>{
      return this.apiService.getAllDetails(globalUrl.country).subscribe(res => {
        resolve(res);
        console.log(res);
    });
    });

  }

  getRegion(){
    return new Promise(resolve =>{
      return this.apiService.getAllDetails(globalUrl.region).subscribe(res => {
        resolve(res);
        console.log(res);
    });
    });
  }

  postCityDetails(payload: any) {
    return new Promise(resolve => {
      this.apiService.postAllDetails(globalUrl.post, payload).subscribe(res => {
        resolve(res);
        console.log(res);
      });
    });
  }

  deleteItemById(cityId: number) {
    
    console.log("this.apis_id=====>", cityId);
    return new Promise(resolve => {
        return this.apiService.deleteItem(globalUrl.delete, cityId).subscribe(res => {
            this.deletedData = res;
            console.log("data", this.deletedData);
                      resolve(res);
        });
    });

}


async getById(id: number) {
  return new Promise(resolve => {
    return this.apiService.getDetailsById(globalUrl.edit, +id).subscribe(
      (res: any) => {
        resolve(res);
        console.log(res);
      },
      (error: any) => {
        
        console.error('Error while fetching data by ID:', error);
        resolve(null); 
      }
    );
  });
  
}

exportData(): Observable<any> {
  const exportUrl = globalUrl.export;
  return this.http.get(exportUrl);
}

async getNextSequence() {
  return new Promise(resolve => {
      return this.apiService.getAllDetails(globalUrl.sequence).subscribe(res => {
          resolve(res);
          console.log("ggggggggggg", res);
      });
  });
}
}



