import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DialogueBoxComponent } from './helpers/dialogue-box/dialogue-box.component';
import { BackdialogComponent } from './helpers/backdialog/backdialog.component';



@NgModule({
  declarations: [
    DialogueBoxComponent,
    BackdialogComponent
  ],
  imports: [
    CommonModule
  ]
})
export class SharedModule { }
