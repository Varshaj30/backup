import { OnInit, Directive } from '@angular/core';
import configJson from "src/assets/config/config.json";
import { Injectable } from '@angular/core';
@Directive()



@Injectable({
    providedIn: 'root',
  })
  export class globalUrl implements OnInit {

    public static city = configJson.gateWayUrl +'/city';

    public static paginate= configJson.gateWayUrl + '/city/pagination';

   public static state = configJson.gateWayUrl + '/master/get-state';

   public static country = configJson.gateWayUrl + '/master/get-country';

   public static region = configJson.gateWayUrl + '/master/get-region';

   public static post = configJson.gateWayUrl + '/city';

   public static delete = configJson.gateWayUrl +'/city';

   public static edit = configJson.gateWayUrl + '/city/cityId';

  public static export = configJson.gateWayUrl + '/city/export';

  public static sequence=configJson.gateWayUrl+'/get-nextSequence';



    ngOnInit(): void {
    }
  }