import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CityListComponent } from './features/city-details/components/city-list/city-list.component';
import { CityFormComponent } from './features/city-details/components/city-form/city-form.component';
import { CityDetailsModule } from './features/city-details/city-details.module';
  const routes: Routes = [

    // {path:'city-list',component:CityListComponent  },
    // {path: 'city-form',component:CityFormComponent},
    
    { path: 'city-details', loadChildren: () => import('./features/city-details/city-details.module').then((m) => m.CityDetailsModule)},
    { path: '', redirectTo: '/city-list', pathMatch: 'full' }, // Redirect to city-list on empty path
  { path: 'city-list', component: CityListComponent },
  { path: 'city-form', component: CityFormComponent },

    // loadChildren: () => import('./features/city-details/components/city-list/city-list.component').then((m) => m.CityListModule
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
