import { Column, GridOption, Formatters, OnEventArgs } from 'angular-slickgrid';
import { HttpClient } from '@angular/common/http';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
import { globalUrl } from 'src/app/shared/helpers/globalUrl';
import { ApiFacade } from '../city.facade';
import { saveAs } from 'file-saver';
import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef,MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { event } from 'jquery';
import { MatDialogModule} from '@angular/material/dialog';
import { DialogboxComponent } from 'src/app/shared/helpers/dialogue-box/dialogue-box.component';
import { ToastrService } from 'ngx-toastr';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import * as XLSX from 'xlsx';
import { MatCheckboxChange } from '@angular/material/checkbox';


@Component({
  selector: 'app-city-list',
  templateUrl: './city-list.component.html',
  styleUrls: ['./city-list.component.css']
})
export class CityListComponent implements OnInit {
  showImportContainer = false;
  cityData: any;
  isFormDirty: boolean = false; 

  [x: string]: any;
  private importedData: any; 
  
  @ViewChild('fileInput') fileInput!: ElementRef;
  draggedFiles: File[] = [];
  dataset1: any[] = [];

  columnDefinitions1: Column[] = [];
  gridOptions1: GridOption;

  paginationConfigForListGrid: any = {
    totalItems: 0,
    itemsPerPage: 50,
    currentPage: 1,
  };
  currentPage = 1;
  pageSize = 50;
  totalPages = 0;
  city: any;
  cityFacade: any;
  paginate:any=[];
  isFormCollapsed: boolean=true;
  selectedItemId!: number;


  constructor(private http: HttpClient, private apiService: ApiFacade,public api: ApiService, 
    public dialog: MatDialog, private toastr: ToastrService, private router: Router,private cdr: ChangeDetectorRef,) {
    this.gridOptions1 = {
      enableAutoResize: false,
      enableFiltering: true, 
      enableSorting: true,
      gridHeight: 300,
      gridWidth: 1400,
      enableCellNavigation: true,

    };this.getAllPaginate(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);
  }
  editForm!: FormGroup; 
  createMode: boolean = false; 

  ngOnInit(): void {

    this.columnDefinitions1 = [
     
      { id: 'sequence', name: 'Sequence', field: 'Sequence', filterable:true, sortable: true },
      { id: 'city', name: 'City', field: 'City', filterable:true, sortable: true },
      { id: 'citycode', name: 'City Code', field: 'City Code', filterable:true,sortable: true },
      { id: 'state', name: 'State', field: 'State',filterable:true, sortable: true },
      { id: 'region', name: 'Region', field: 'Region',filterable:true, sortable: true },
      { id: 'country', name: 'Country', field: 'Country',filterable:true, sortable: true },
      { id: 'description', name: 'Description', field: 'Description', filterable:true,sortable: true },
      { id: 'isAnchorTagged', name: 'Anchor Tag', field: 'isAnchorTagged', maxWidth: 100, formatter: this.anchorTagFormatter },
      
    
      {
        id: 'edit',
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
     

        onCellClick: (e: Event, args: OnEventArgs) => {
          console.log("args.dataContext",args.dataContext.cityId);
          this.selectedItemId = args.dataContext.cityId;
          console.log("city_id ",this.selectedItemId);
          this.router.navigate(['/city-form'], { queryParams: { selectedItemId: args.dataContext.cityId} });
        },
        formatter: this.editIconFormatter
      },
      {
        id: 'delete',
        name: 'Action',
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        onCellClick: (e: Event, args: OnEventArgs) => {
          console.log("args.dataContext",args.dataContext.cityId);
          this.selectedItemId = args.dataContext.cityId;
          this.openDialog(e, args);
       
        },
        formatter: Formatters.deleteIcon
      },
      {
        id: 'clone',
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        onCellClick: (e: Event, args: OnEventArgs) => {
          console.log("args.dataContext",args.dataContext.ifscId);
          this.selectedItemId = args.dataContext.cityId;
          console.log(this.selectedItemId);

          this.router.navigate(['/city-form'],{queryParams:{selectedItemId:args.dataContext.cityId,cloneFlag:1}});
        },
        formatter: this.cloneIconFormatter,
        
      }
    ]


  }

  getPaginatedData(): any[] {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    return this.dataset1.slice(startIndex, endIndex);
  }

 onImportClicked(): void {
 
}


onFileSelected(event: any) {
  const files: FileList = event.target.files;
  this.draggedFiles = [];
  for (let i = 0; i < files.length; i++) {
    this.draggedFiles.push(files[i]);
  }
}
onFileInputClicked() {
  const fileInput = this.fileInput.nativeElement;
  fileInput.click();
}

onDragOver(event: any): void {
  event.preventDefault();
  this['isDragOver'] = true;
}
onDragLeave(event: any) {
  event.preventDefault();
  this['isDragOver'] = false;
}
onFileDropped(event: any): void {
  event.preventDefault();
  const files = event.dataTransfer.files;
  if (files.length > 0) {
    
    for (let i = 0; i < files.length; i++) {
      this.draggedFiles.push(files[i]);
    }
  }
}

readFileContents(file: File): void {
  const reader = new FileReader();
  reader.onload = (event: any) => {
    const contents = event.target.result; 
    this.dataset1 = JSON.parse(contents); 
    this['angularGridInstances'].forEach((grid: { dataView: { refresh: () => any; }; }) => grid?.dataView?.refresh());
  };
  reader.readAsText(file);
}

addFiles() {

  this['data'].push(...this.draggedFiles);

  this.draggedFiles = [];
}

removeDraggedFile(file: File) {
  const index = this.draggedFiles.indexOf(file);
  if (index !== -1) {
    this.draggedFiles.splice(index, 1);
  }
}
toggleImportContainer(): void {
  this.showImportContainer = !this.showImportContainer;
  if (this.showImportContainer) {
    const fileInput = document.getElementById('fileInput') as HTMLInputElement;
    fileInput.click();
  }
}

  getAllCitys() {
    {
      this.city = this.apiService.getAllCity();
      console.log(this.city);
    }
  }

  async getAllPaginate(pageNumber: number, pageSize: number) {
    console.log('inside getAllBranchs facade')
    return new Promise(resolve => {
      return this.api.getDetailsPagination(globalUrl.paginate, pageNumber, pageSize).subscribe((res: any) => {
        console.log("ress==>", res);

        this.paginate = res.data;
        console.log("this.paginate", this.paginate);

        this.paginate.forEach((item: { id: any; }, index: number) => {
          item.id = index + 1;
        });
        this.dataset1 = this.paginate;
        console.log("this.cities==", this.dataset1);

        console.log("cities", this.paginate);
        resolve(this.paginate);
      })

    })
  }

  onPageChange(page: number): void {
    this.currentPage = page;
  
  }

  cloneIconFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<i class="fa fa-clone clickable" style="cursor: pointer;"></i>`;
  }
  // anchorTagFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
  //   return `<i class="fa-solid fa-anchor" style="cursor: pointer;"></i>`;
  // }

  anchorTagFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
     console.log(dataContext.isAnchorTagged);
     
    if (dataContext.isAnchorTagged == true) {
     
      return '<i class="fa-solid fa-anchor" style="cursor: pointer;"></i>';
    
    } else {
      return 'fsdf';
      
    }
  }
  
  
  onAnchorTagChange(item: any, event: MatCheckboxChange): void {
    item.isAnchorTagged = event.checked;
    this['angularGridInstances'].forEach((grid: { dataView: { refresh: () => any; }; }) => grid?.dataView?.refresh());
    this.cdr.detectChanges(); 
  }
  
  editIconFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<i class="fa fa-edit clickable" style="cursor: pointer;" title="Edit"></i>`;
  }
  

  cloneItem(row: number): void {
    console.log('Clone icon clicked on row:', row);

  }

  addNewUser(): void {

  }

  toggleFormCollapse() {
    this.isFormCollapsed = !this.isFormCollapsed;
  } 



  onDeleteRecord(cityId: number): void {
    this.selectedItemId = cityId;
    this.openDialog('delete', { cityId });
  }
 
  openDialog(action: any, obj: any){

    obj.action = action;

    console.log("Inside the dialog ");
   const dialogRef= this.dialog.open(DialogboxComponent, {  

      
        })
    

    dialogRef.afterClosed().subscribe((result:boolean) => {
   
      if (result === true) {
        console.log("Inside the dialog 2234");
       
        this.deleteData();
      }
    });
}
async deleteData() 
{

  await this.apiService.deleteItemById(this.selectedItemId)
  console.log("city_id", this.selectedItemId);
  this.toastr.success('Data deleted successfully!', 'Success');
  this.getAllPaginate(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);

 }

 exportData(): void {

  const exportUrl = globalUrl.export;
this.api.downloadFile(exportUrl).subscribe(
  (data) => {
    
    console.log('Exported data:', data);
    this.toastr.success('Data exported successfully!', 'Success');
  },
  (error) => {
    console.error('Error exporting data:', error);
    this.toastr.error('Error exporting data', 'Error');
  }
);
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(this.dataset1); 

  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([wbout], { type: 'application/octet-stream' });
  saveAs(blob, 'exported_data.xlsx');

  console.log('Exported============>')
}

convertToCSV(data: any[]): string {
  let csvContent = 'cityId,stateId,stateName,cityName,countryId,regionId,regionName\n';



  for (const item of data) {
    const row = `${item.pincodeId},${item.stateId},${item.stateName},${item.cityName},${item.countryId},${item.regionId},${item.regionName}\n`;  // here you must replace sequence , ifscCode and micrCode to your column titles of list 
    csvContent += row;
  }

  return csvContent;
}
//-----------------------------

handleAnchorTagged(value: boolean): void {
  console.log('Anchor tag value---------------:', value);
  // Do whatever you need to do with the anchor tag value here
}



}