import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr'; 
import { ApiFacade } from '../city.facade';
import { Router } from '@angular/router';
import { log } from 'console';
import { ActivatedRoute } from '@angular/router';
import { DialogboxComponent } from 'src/app/shared/helpers/dialogue-box/dialogue-box.component';
import { MatDialogRef,MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { BackdialogComponent } from 'src/app/shared/helpers/backdialog/backdialog.component';
import { combineLatest } from 'rxjs';

@Component({
  selector: 'app-city-form',
  templateUrl: './city-form.component.html',
  styleUrls: ['./city-form.component.css']
})
export class CityFormComponent implements OnInit {
  @Output() anchorTagged: EventEmitter<boolean> = new EventEmitter<boolean>();
  cityForm !: FormGroup ;
  form: any;
  isFormCollapsed: boolean =true;
  dataFromApi: any;
  minDate!: Date;
  city: any;
  stateary:any=[];
  countryary:any=[];
  regionary:any=[];
  message!: string;
  cityList: any= [];
  createdBy:any;
  createdDate:any;
  createMode: boolean = false; 
  isFormDirty: boolean = false; 
  cityData: any;
  radioOptionsYesNo : any= [
    {
        "rowId": true,
        "title": "Yes"
    },
    {
        "rowId": false,
        "title": "No"
    }
  ];
  apiFacade: any;
  params: any;
  branchFacade: any;
  createCity!: boolean;
  dialog: any;
  formSaved: any;
  num: any;

  
  constructor(private formBuilder: FormBuilder, public dialogue: MatDialog,
    private toastr: ToastrService, private apiService:ApiFacade,  public router: Router ,public activate:ActivatedRoute,) 
    
    { 


      this.activate.queryParams.subscribe(params => {
        this.params = params;
        console.log("this.params", this.params);
      })
    


    }
  
  toggleFormCollapse() {
    this.isFormCollapsed = !this.isFormCollapsed;
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
        cityName: ['',[ Validators.required, Validators.maxLength(50), Validators.pattern('[a-zA-Z ]*')]],
        stateId: [null, Validators.required],
        sequence: ['', [Validators.required,Validators.pattern('^[0-9]*$')]],
        isAnchorTagged: [false],

        cityCode: ['', [Validators.required, Validators.maxLength(20),Validators.pattern('^[a-zA-Z0-9]*$')]],
        target_in_cr: ['', [Validators.required, Validators.maxLength(9),Validators.pattern('^[0-9]*$')]],
        fromDate: ['', [this.dateValidator()]],
        isActive: [false],
        regionId: [null, Validators.required],
        
        description: ['', [Validators.required, Validators.maxLength(200),Validators.pattern('[a-zA-Z ]*')]],
        countryId: [null, Validators.required],    
        isRestricted: [false],
        isExcluded: [false],
        toDate: ['', Validators.required], 
  
      })
    
    this.minDate = new Date();
    this.getStates();
    this.getCountrys();
    this.getRegions();
    this.getNextSequen();
 
    
    this.getCityById();
 
  }

  get f() {
    return this.form.controls;
  }


  onFromDateChange() {
    const fromDateValue = this.form.get('fromDate')?.value;
    const currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);
  
    if (fromDateValue === this.getFormattedDate(currentDate)) {
      this.form.get('isActive')?.setValue(true);
      this.form.get('toDate')?.enable();
    } else {
      this.form.get('isActive')?.setValue(false);
      this.form.get('toDate')?.disable();
    }
  }
  
  onToDateChange() {
    const toDateValue = this.form.get('toDate')?.value;
    const currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);
  
    if (toDateValue === this.getFormattedDate(currentDate)) {
      this.form.get('isActive')?.setValue(true);
    } else {
      this.form.get('isActive')?.setValue(false);
    }
  }
  
  getFormattedDate(date: Date): string {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  }


  dateValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const selectedDate = new Date(control.value);
      const currentDate = new Date();
      currentDate.setHours(0, 0, 0, 0);
  
      if (selectedDate < currentDate) {
        control.parent?.get('toDate')?.disable();
        control.parent?.get('isActive')?.setValue(false);
        return { 'invalidDate': true };
      } else {
        control.parent?.get('toDate')?.enable();
        control.parent?.get('isActive')?.setValue(true);
      }
  
      return null;
    };
  }
  
  getMinToDate(): Date | null {
    const fromDateControl = this.form.get('fromDate');
    if (fromDateControl && fromDateControl.value) {
      return new Date(fromDateControl.value);
    }
    return null;
  }
  
 
  saveForm(param: any): void {



    if (this.form.valid) {
      var payload: any = {};
      this.createdBy = "3fa85f64-5717-4562-b3fc-2c963f66afa6"
      this.createdDate = "2023-07-20T12:03:23.796Z"
      payload = this.form.value;
      payload.createdBy = this.createdBy
      payload.createdDate = this.createdDate


      if(this.params.selectedItemId && this.params.cloneFlag){
        this.cityData={... this.form.value};
        payload={...this.cityData,selectedItemId:0,createdBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6"};
        console.log('Payload of Clone--->',payload);
      }
      if (this.params.selectedItemId) {
        Object.assign(this.cityData, this.form.value);
        payload = this.cityData;

      }
      
      this.apiService.postCityDetails(payload);
     
      if (param == 'saveAndContinued') {
        console.log("param", param);
        this.form.reset();
   
        this.toastr.success('Record saved successfully!', 'Success')
      }
      else if (param =='save') {
      console.log("param",param);
      this.toastr.success('Record saved successfully!', 'Success')
      
      this.router.navigate(['/city-list']);
      
      }
    }
    else
    {
      this.toastr.error('Please fill in all the required fields.', 'Error');

      if (this.formSaved) {
        this.clearInvalidToaster(); 
      }
    }
    


  }
  clearInvalidToaster() {
    throw new Error('Method not implemented.');
  }

  onBack() {
  
   console.log('Back button clicked');
 
    const dialogRef = this.dialogue.open(BackdialogComponent, {
   
    });
  
    dialogRef.afterClosed().subscribe((result: boolean) => {
      if (result) {
        this.toastr.warning('The Information may get lost! Please Save it First', 'Warning');
        this.router.navigate(['/city-list']);
      }
    });
  }
  
  async getStates(){
        {
          this.stateary = await this.apiService.getState();
          console.log("listOfState",this.stateary);
        }
      }


    
  async  getCityById() {
     
      if (this.params && this.params.selectedItemId) {

        this.cityData = await this.apiService.getById(this.params.selectedItemId);
     
      this.createCity = false;
    this.form.patchValue({
    
      cityName: this.cityData.cityName, 
      description: this.cityData.description,
      isActive: this.cityData.isActive,
      target_in_cr: this.cityData.target_in_cr,
      sequence: this.cityData.sequence,
      isAnchorTagged:this.cityData.isAnchorTagged,
      stateId:this.cityData.stateId,
      cityCode:this.cityData.cityCode,
      fromDate:this.cityData.fromDate,
      regionId:this.cityData.regionId,
      countryId:this.cityData.countryId,
      isRestricted:this.cityData.isRestricted,
      isExcluded:this.cityData.isExcluded,
      toDate:this.cityData.toDate,
    });
  }
   
}

     async getCountrys(){
        {
          this.countryary = await this.apiService.getCountry();
          console.log(this.countryary);
        }
      }
      
    async  getRegions(){
        {
          this.regionary = await this.apiService.getRegion();
          console.log(this.regionary);
        }
      }
      isFieldValid(field: string) {
   
        const formControl = this.form.get(field);
        return formControl ?  formControl.valid && formControl.touched:false;
      }
    
    
      isFieldTouched(field: string): boolean {
        const control = this.form.get(field);
        return control ? control.touched : false;
      }   

      async getNextSequen() {
        this.num = await this.apiService.getNextSequence();
        console.log("this.sequence ", this.num);
      this.form.get("sequence")?.patchValue(this.num);
      
      
      }

      // anchor tag------------------------------
      onAnchorTagChange(event: any): void {
         console.log("Pratham ",event);
        this.anchorTagged.emit(event);
        
      }

}





